from django.apps import AppConfig


class FeeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Fee'
